"use client";
 
import styles from './page.module.css';

import Sidebar from '@/components/ui/Sidebar/Sidebar';
import Header from '@/components/ui/Header/Header';
import CustomTable from '@/components/ui/Table/Table';
import CadastroModal from "@/components/ui/Modal/FormCad/CadastroModal";

import { useState } from 'react';
import { useAuth } from '@/app/auth.js';
import { useMoradores } from '@/features/morador/hooks/useMorador';
import { useEntityModal } from '@/hooks/useEntityModal';

import { createMorador } from '@/features/morador/services/moradorPOST';
import { updateMorador } from '@/features/morador/services/moradorPUT';

import { moradorFields } from '@/components/ui/Modal/FormCad/formConfigs';
import { extractFilterMoradores, filterMoradores } from "@/filters";
import { InjectMoradoresTable } from '@/utils/dataInject';
import { NAV_ITENS_MORADORES } from '@/filters';
import { useBlocoOptions } from "@/features/bloco/hooks/useBlocoOptions";
import { useMoradiaOptions } from "@/features/moradia/hooks/useMoradiaOptions";


  export default function Moradores() {
      const { user } = useAuth();
      const canManage = user?.role.includes("ROLE_ADMIN") || user?.role.includes("ROLE_SINDICO");
      
      const { data, fetchMoradores, removeMoradores, isLoading } = useMoradores();
      
      const modal = useEntityModal({
          onCreate:  createMorador,
          onUpdate:  (id, formData) => updateMorador(id, formData),
          getId:     (item) => item.idMorador,
          onRefresh: fetchMoradores,
        });
        
        const [search, setSearch] = useState("");
        const [debouncedSearch, setDebouncedSearch] = useState("");
        const [filters, setFilters] = useState({ selectedUsers: [], startDate: "", endDate: "" });
        const { options: blocoOptions }   = useBlocoOptions();
        const { options: moradiaOptions } = useMoradiaOptions();

    const [activeTab, setActiveTab] = useState("Todos");

const fieldsComLocalizacao = [
    ...moradorFields,
    {
      name: "idBloco",
      label: "Bloco",
      placeholder: "Selecione o bloco",
      type: "select",
      options: blocoOptions,
    },
    {
      name: "idMoradia",
      label: "Moradia",
      placeholder: "Selecione a moradia",
      type: "select",
      options: moradiaOptions,     
      dependsOn: "idBloco",        
      filterField: "idBloco",      
    },
  ];

    return (    
        <div className={styles.body}>
            <Sidebar />
            <div className={styles.main}>
                <Header
                    titulo="Moradores registrados"
                    search={search}
                    setSearch={setSearch}
                    setDebouncedSearch={setDebouncedSearch}
                    canAdd={canManage}
                    onAddbuttonClick={modal.openAdd}
                    users={extractFilterMoradores(data)}
                    filters={filters}
                    onFiltersChange={setFilters}
                    navItens={NAV_ITENS_MORADORES}
                    setActiveTab={setActiveTab}
                    activeTab={activeTab}
                />
 
                <CustomTable
                    headerAs="span"
                    rowsPerPage={10}
                    columns={InjectMoradoresTable()}
                    data={filterMoradores(data, activeTab, filters)}
                    searchValue={debouncedSearch}
                    onRowClick={modal.openEdit}
                    onDeleteConfirm={removeMoradores}
                    canRemove={canManage}
                    isLoading={isLoading}
                />
            </div>
 

                <CadastroModal
                    show={modal.open}
                    onHide={modal.close}
                    title={modal.tipo === "edit" ? "Editar Morador" : "Adicionar Morador"}
                    fields={fieldsComLocalizacao}
                    initialData={modal.itemData ?? {}}
                    onSaveChanges={modal.save}
                    showPhoto={true}
                />

        </div>
    );
}
 