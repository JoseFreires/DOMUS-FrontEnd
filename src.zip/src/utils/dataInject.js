import { formatDateTime } from "@/utils/formatar";
import styles from "@/app/pages/encomendas/page.module.css";
import { ChamadoType } from "@/features/chamado/components/tableComponents/ChamadoType/type";
import { ChamadoStatus } from "@/features/chamado/components/tableComponents/ChamadoStatus/status";

export function InjectEncomendasTable() {
  return [
    {
      label: "MORADOR",
      key: "nomeMorador",
      render: (value, row) => (
        <div className={styles.user}>
          <span>{value}</span>
          <small>{row.emailDestinatario}</small>
        </div>
      ),
    },
    {
      label: "NOME DO PACOTE",
      key: "nomePacote",
    },
    {
      label: "DATA - HORA",
      key: "dataHoraRecebido",
      render: (value) => <p className={styles.tableLine}>{formatDateTime(value)}</p>,
    },
    {
      label: "APARTAMENTO",
      key: "numeroApartamento",
      render: (value) => <p className={styles.tableLine}>{value}</p>,
    },
  ];
}

export function InjectMoradoresTable() {
  return [
    {
      label: "NOME",
      key: "nomeCompleto",
      render: (value, row) => (
        <div className={styles.user}>
          <span>{value}</span>
          <small>{row.email}</small>
        </div>
      ),
    },
    {
      label: "TELEFONE",
      key: "telefone",
    },
    {
      label: "APARTAMENTO",
      key: "numeroApartamento",
    },
    {
      label: "BLOCO",
      key: "bloco"
    },
  ]
}

export function InjectPorteirosTable() {
  return [
    {
      label: "NOME",
      key: "nomeCompleto",
      render: (value, row) => (
        <div className={styles.user}>
          <span>{value}</span>
          <small>{row.email}</small>
        </div>
      ),
    },
    {
      label: "TELEFONE",
      key: "telefone",
    },
    {
      label: "TURNO",
      key: "turno",
      render: (value) => (
        <p className={styles.tableLine}>
          {{ MANHA: "Manhã", TARDE: "Tarde", NOITE: "Noite" }[value] ?? value}
        </p>
      ),
    },
    {
      label: "EMPRESA",
      key: "empresaResponsavel",
      render: (value) => <p className={styles.tableLine}>{value}</p>,
    },
  ];
}

export function InjectSindicosTable() {
  return [
    {
      label: "NOME",
      key: "nomeCompleto",
      render: (value, row) => (
        <div className={styles.user}>
          <span>{value}</span>
          <small>{row.email}</small>
        </div>
      ),
    },
    {
      label: "TELEFONE",
      key: "telefone",
    },
    {
      label: "NASCIMENTO",
      key: "dataNascimento",
      render: (value) => (
        <p className={styles.tableLine}>
          {value ? new Date(value).toLocaleDateString("pt-BR") : "—"}
        </p>
      ),
    },
    {
      label: "STATUS",
      key: "ativo",
      render: (value) => (
        <span className={`badge ${value ? "bg-success" : "bg-secondary"}`}>
          {value ? "Ativo" : "Inativo"}
        </span>
      ),
    },
  ];
}


export function InjectSolicitacoesReservasEspacosCondominiaisTable() {
  return [
    {
      label: "LOCAL",
      key: "local",
      render: (value, row) => (
        <div className={styles.user}>
          <span>{value}</span>
          <small>{row.email}</small>
        </div>
      ),
    },
    {
      label: "MORADOR",
      key: "morador",
    },
    {
      label: "APARTAMENTO",
      key: "numeroApartamento",
    },
    {
      label: "BLOCO",
      key: "bloco"
    },
    {
      label: "DATA",
      key: "data"
    },
  ]
}

export function InjectVisitantesTable() {
  return [
    {
      label: "NOME",
      key: "nome",
    },
    {
      label: "DATA - HORA",
      key: "dataHoraChegada",
      render: (value) => <p className={styles.tableLine}>{formatDateTime(value)}</p>,
    },
    {
      label: "TIPO",
      key: "nomeTipoVisita"
    },
    {
      label: "PORTEIRO",
      key: "nomePorteiro"
    },
    {
      label: "APARTAMENTO",
      key: "moradia"
    },
    {
      label: "BLOCO ",
      key: "bloco"
    },

  ]
}

export function InjectAvisosTable() {
  return [
    {
      label: "CRIADOR",
      key: "nomeSindico",
      render: (value, row) => (
        <div className={styles.user}>
          <span>{value ?? row.nomeCriador ?? row.nomeCompleto ?? "—"}</span>
          <small>{row.emailSindico ?? row.emailCriador ?? row.email ?? ""}</small>
        </div>
      ),
    },
    {
      label: "TITULO",
      key: "titulo",
    },
    {
      label: "DATA DE CRIAÇÃO",
      key: "dataHoraAviso",
      render: (value) => <p className={styles.tableLine}>{formatDateTime(value)}</p>,
    },
    {
      label: "TIPO DE AVISO",
      key: "tipoAviso",
      render: (value) => (
        <p className={styles.tableLine}>
          {{ MANUTENCAO: "MANUTENÇÃO" }[value] ?? value}
        </p>
      ),
    },
  ];
}

export function InjectConvidadosTable(){
  return[];
}

export function InjectChamadosTable() {
  return [
    {
      label: "MORADOR",
      key: "nomeMorador",
      render: (value, row) => (
        <div className={styles.user}>
          <span>{value ?? row.nomeCompleto ?? "—"}</span>
        </div>
      ),
    },
    {
      label: "ASSUNTO",
      key: "titulo",
      render: (value, row) => value ?? row.assunto ?? "—",
    },
    {
      label: "DATA DE CRIAÇÃO",
      key: "dataHoraAbertura",
      render: (value, row) => (
        <p className={styles.tableLine}>
          {formatDateTime(
            value ?? row.dataCriacao ?? row.dataHoraChamado ?? row.datadecriação
          ) || "—"}
        </p>
      ),
    },
    {
      label: "TIPO",
      key: "tipoChamado",
      render: (value, row) => (
        <ChamadoType value={value ?? row.tipo} />
      ),
    },
    {
      label: "STATUS",
      key: "statusChamado",
      render: (value, row) => <ChamadoStatus value={value ?? row.status} />,
    },
  ];
}