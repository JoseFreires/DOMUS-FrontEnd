import { isWithinDateRange, parseItemDate } from "@/utils/dateUtils.js";

export const NAV_ITENS_CHAMADOS = [
  { texto: "Todos" },
  { texto: "Abertos" },
  { texto: "Cancelados" },
];

function normalizeValue(value) {
  return value
    ?.normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[_-]/g, " ")
    .trim()
    .toUpperCase() ?? "";
}

function getResidentName(item) {
  return item.nomeMorador ?? item.nomeCompleto ?? "";
}

function getCalledType(item) {
  return item.tipoChamado ?? item.tipo ?? "";
}

function getCalledStatus(item) {
  return normalizeValue(item.statusChamado ?? item.status);
}

function getCalledDate(item) {
  return (
    item.dataHoraCriacao ??
    item.dataCriacao ??
    item.dataHoraChamado ??
    item.datadecriação
  );
}

const TAB_FILTERS = {
  Todos: () => true,
  Abertos: (item) => ["ABERTO", "PENDENTE"].includes(getCalledStatus(item)),
  Tratando: (item) => getCalledStatus(item) === "TRATANDO",
  Concluidos: (item) =>
    ["CONCLUIDO", "FINALIZADO", "RESOLVIDO"].includes(getCalledStatus(item)),
  Cancelados: (item) => getCalledStatus(item) === "CANCELADO",
};

export function extractFilterChamadosUsers(data) {
  return Array.from(
    new Set((data ?? []).map(getResidentName).filter(Boolean)),
  ).sort();
}

export function extractFilterChamadosTypes(data) {
  return Array.from(
    new Set((data ?? []).map(getCalledType).filter(Boolean)),
  ).sort();
}

export function filterChamados(data, activeTab = "Todos", filters = {}) {
  const tabFilter = TAB_FILTERS[activeTab] ?? TAB_FILTERS.Todos;
  const { selectedUsers = [], selectedTypes = [] } = filters;

  return (data ?? [])
    .filter(tabFilter)
    .filter((item) => {
      if (selectedUsers.length && !selectedUsers.includes(getResidentName(item))) {
        return false;
      }

      if (selectedTypes.length && !selectedTypes.includes(getCalledType(item))) {
        return false;
      }

      return isWithinDateRange(parseItemDate(getCalledDate(item)), filters);
    });
}
